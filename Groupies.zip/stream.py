from draw import *
from music21.note import Note
from music21 import pitch, duration
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtGui import QPainter
from PyQt5.QtCore import Qt
from note import *

class Stream:
    def __init__(self):

